import React, { useEffect } from 'react';
import { GraduationCap, Heart, Volume2, Sparkles, CheckCircle, X, ArrowLeft } from 'lucide-react';

interface TeacherModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartSession: (prompt: string) => void;
  isDark: boolean;
}

export const TeacherModeModal: React.FC<TeacherModeModalProps> = ({
  isOpen,
  onClose,
  onStartSession,
  isDark,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const teacherPrompts = [
    {
      title: '🎯 Class 12 MP Board 30-Day Study Strategy',
      prompt: 'Aura Ma\'am, कृपया मुझे MP Board कक्षा 12वीं के लिए अगले 30 दिनों का विषयवार टाइम टेबल और रिवीजन रणनीति समझाइए।',
    },
    {
      title: '💡 कठिन फॉर्मूले और डेरिवेशन याद रखने की ट्रिक',
      prompt: 'ऑरा मैम, फिजिक्स और केमिस्ट्री के बड़े डेरिवेशंस और फॉर्मूले बिना भूले कैसे याद रखें? आसान टिप्स दीजिए।',
    },
    {
      title: '📝 बोर्ड परीक्षा में 90%+ स्कोर करने हेतु उत्तर लेखन शैली',
      prompt: 'Aura, बोर्ड परीक्षा की उत्तर पुस्तिका में 5 अंक और 3 अंक वाले प्रश्नों को स्टेप-बाय-स्टेप कैसे लिखें ताकि पूरे नंबर मिलें?',
    },
    {
      title: '🧘 परीक्षा तनाव और एकाग्रता बढ़ाने के उपाय',
      prompt: 'मैम, परीक्षा के दिनों में ध्यान भटकता है और स्ट्रेस होता है। कृपया शांत मन से पढ़ाई करने का मार्गदर्शन दीजिए।',
    },
  ];

  return (
    <div 
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        className={`relative w-full max-w-[640px] rounded-3xl p-6 sm:p-7 shadow-2xl border transition-all ${
          isDark ? 'bg-[#111c33] border-[#293d63] text-white' : 'bg-white border-[#e2e8f0] text-[#0f172a]'
        }`}
      >
        {/* Top bar with unmistakable Close buttons (User: "use htane option to do htao kese") */}
        <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-slate-100 dark:border-slate-800">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>← डैशबोर्ड</span>
          </button>

          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-900/50 text-xs font-bold text-red-600 dark:text-red-400 transition-all cursor-pointer"
            title="हटाएँ (Close)"
          >
            <X className="w-4 h-4" />
            <span>✕ विंडो हटाएं / बंद करें</span>
          </button>
        </div>

        {/* Persona Header */}
        <div className="flex items-center gap-4 mb-5">
          <div className="relative">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-pink-500 via-rose-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-pink-500/25">
              <GraduationCap className="w-7 h-7" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white dark:border-[#111c33] flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
            </div>
          </div>
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300">
              <Heart className="w-3 h-3 fill-current" />
              <span>Dedicated Female Tutor & Mentor</span>
            </div>
            <h3 className="text-xl font-bold tracking-tight mt-0.5">ऑरा मैम (Aura - आपकी शिक्षिका)</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              सहानुभूतिपूर्ण, धैर्यवान और स्पष्ट शिक्षण दृष्टिकोण के साथ 24/7 उपलब्ध।
            </p>
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-2 gap-2.5 mb-6 text-xs">
          <div className={`p-3 rounded-xl border flex items-center gap-2 ${
            isDark ? 'border-[#223555] bg-[#0b1322]' : 'border-slate-100 bg-slate-50'
          }`}>
            <Volume2 className="w-4 h-4 text-blue-500 shrink-0" />
            <span>मधुर महिला आवाज़ (Hindi/English TTS)</span>
          </div>
          <div className={`p-3 rounded-xl border flex items-center gap-2 ${
            isDark ? 'border-[#223555] bg-[#0b1322]' : 'border-slate-100 bg-slate-50'
          }`}>
            <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
            <span>ChatGPT-स्तरीय सरल एवं विस्तृत स्पष्टीकरण</span>
          </div>
        </div>

        {/* Topics */}
        <div className="space-y-2 mb-6">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            विशेष मार्गदर्शन सत्र चुनें:
          </div>
          {teacherPrompts.map((item, idx) => (
            <button
              key={idx}
              onClick={() => {
                onStartSession(item.prompt);
                onClose();
              }}
              className={`w-full text-left p-3.5 rounded-xl border text-xs font-medium transition-all flex items-center justify-between cursor-pointer ${
                isDark 
                  ? 'border-[#203152] bg-[#0b1322] hover:border-pink-500 text-slate-200' 
                  : 'border-slate-200 bg-slate-50 hover:border-pink-500 hover:bg-pink-50/50 text-slate-800'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <CheckCircle className="w-4 h-4 text-pink-500 shrink-0" />
                <span className="font-semibold">{item.title}</span>
              </div>
              <span className="text-[11px] text-pink-600 dark:text-pink-400 font-bold shrink-0">प्रारंभ करें ›</span>
            </button>
          ))}
        </div>

        <div className="text-center text-[11px] text-slate-400 italic">
          "कोई भी संदेह छोटा नहीं होता। निस्संदेह पूछें, मैं हमेशा आपके साथ हूँ!" — ऑरा
        </div>
      </div>
    </div>
  );
};
